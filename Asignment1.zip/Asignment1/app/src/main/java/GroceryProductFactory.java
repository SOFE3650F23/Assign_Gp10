public class GroceryProductFactory {
	BananaFactory bananaFactory = new BananaFactory();
	AppleFactory appleFactory = new AppleFactory();
	OrangeFactory orangeFactory = new OrangeFactory();
	
	GroceryProductFactory(){}
	
	public Product createProduct(String id){
		Product product = null;
		if(id == bananaFactory.getId()){
			product = bananaFactory.createProduct();
		}else if(id == appleFactory.getId()){
			product = appleFactory.createProduct();
		}else if(id == orangeFactory.getId()){
			product = orangeFactory.createProduct();
		}
		
		if(product != null){ System.out.println("New " + id + " created!"); }
		else{ System.out.println("Failed to create " + id + ", not defined."); }
		return product;
	}
}