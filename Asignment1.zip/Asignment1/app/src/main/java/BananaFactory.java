public class BananaFactory {
	private String id = "Banana";
	private float price = 2.99f;
	
	BananaFactory(){}
	
	public Product createProduct(){ return new Product(id, price); }
	
	public String getId(){ return id; }
	public float getPrice(){ return price; }	
}