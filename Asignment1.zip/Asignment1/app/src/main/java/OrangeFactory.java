public class OrangeFactory {
	private String id = "Orange";
	private float price = 1.99f;
	
	OrangeFactory(){}
	
	public Product createProduct(){ return new Product(id, price); }
	
	public String getId(){ return id; }
	public float getPrice(){ return price; }	
}