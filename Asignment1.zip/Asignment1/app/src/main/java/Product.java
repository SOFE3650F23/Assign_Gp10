public class Product {
	private String id;
	private float price;
	
	Product(String id, float price){
		this.id = id;
		this.price = price;
	}
	
	public String getId(){ return id; }
	public float getPrice(){ return price; }
	
}