public class Main {
	public static void main(String[] args) {
		GroceryProductFactory factory = new GroceryProductFactory();
		
		Product banana = factory.createProduct("Banana");
		Product banana2 = factory.createProduct("Banana");
		System.out.println("Product ID: " + banana.getId() + ", Price: $" + String.valueOf(banana.getPrice()) + "\n");
		
		Product apple = factory.createProduct("Apple");
		System.out.println("Product ID: " + apple.getId() + ", Price: $" + String.valueOf(apple.getPrice()) + "\n");
		
		Product orange = factory.createProduct("Orange");
		System.out.println("Product ID: " + orange.getId() + ", Price: $" + String.valueOf(orange.getPrice()) + "\n");
		
	}
}