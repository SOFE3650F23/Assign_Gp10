public class AppleFactory {
	private String id = "Apple";
	private float price = 1.50f;
	
	AppleFactory(){}
	
	public Product createProduct(){ return new Product(id, price); }
	
	public String getId(){ return id; }
	public float getPrice(){ return price; }	
}